package com.example.newaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NewsdeatilActivity extends AppCompatActivity {
    String title, desc, content, imageURL, url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newsdeatil);
        title = getIntent().getStringExtra("title");
        desc = getIntent().getStringExtra("desc");
        imageURL = getIntent().getStringExtra("image");
        url = getIntent().getStringExtra("url");
        content = getIntent().getStringExtra("content");
    }
}
